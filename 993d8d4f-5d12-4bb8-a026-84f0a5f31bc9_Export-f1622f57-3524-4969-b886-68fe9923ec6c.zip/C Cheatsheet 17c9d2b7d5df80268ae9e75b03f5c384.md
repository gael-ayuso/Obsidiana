# C Cheatsheet

## Sintaxis Basica

- **#include <stdio.h>:** Es una librería que va en el encabezado que nos da algunas funciones estándar como **printf** y **scanf**.
- **int main( )**: La funcion main( ) es punto de entrada de cualquier programa de C, es decir, cualquier cosa que se encuentre dentro de los